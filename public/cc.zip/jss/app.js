$(document).ready(function(){

	$('#player').videre({
		video: {
			quality: [
				{
					label: '720p',
					src: 'https://fac-it.net/version/upload_dir/content/SATTAM.mp4?HD'
				},
				{
					label: '360p',
					src: 'https://fac-it.net/version/upload_dir/content/SATTAM.mp4?SD'
				},
				{
					label: '240p',
					src: 'https://fac-it.net/version/upload_dir/content/SATTAM.mp4?SD'
				}
			],
			title: 'Focus Media '
		},
		dimensions: 768
	});

});